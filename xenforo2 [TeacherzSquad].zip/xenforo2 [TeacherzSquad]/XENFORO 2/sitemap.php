<?php

$dir = __DIR__;
require ($dir . '/src/XF.php');

XF::start($dir);
$app = XF::setupApp('XF\Pub\App');

header('X-Robots-Tag: noindex');

/** @var \XF\Repository\SitemapLog $sitemapRepo */
$sitemapRepo = $app->repository('XF:SitemapLog');
$sitemap = $sitemapRepo->getActiveSitemap();
if (!$sitemap)
{
	header('Content-Type: text/plain; charset=utf-8', true, 404);
	echo 'no sitemap';
	exit;
}

$counter = isset($_GET['c']) && is_string($_GET['c']) ? intval($_GET['c']) : null;

if (!$counter)
{
	if ($sitemap->file_count > 1)
	{
		$builder = $app->sitemapBuilder();
		header('Content-Type: application/xml; charset=utf-8');
		header('Content-Disposition: inline; filename="sitemap-index.xml"');
		echo $builder->buildIndex($sitemap);
		exit;
	}

	$counter = 1;
}

$fileName = $sitemap->getAbstractedSitemapFileName($counter);
$fs = \XF::fs();
if ($fs->has($fileName))
{
	if ($sitemap->is_compressed)
	{
		header('Content-Type: application/gzip; charset=utf-8');
		header('Content-Disposition: attachment; filename="sitemap-' . $counter . '.xml.gz"');
	}
	else
	{
		header('Content-Type: application/xml; charset=utf-8');
		header('Content-Disposition: inline; filename="sitemap-' . $counter . '.xml"');
	}

	$stream = $fs->readStream($fileName);
	fpassthru($stream);
	@fclose($stream);
}
else
{
	header('Content-Type: text/plain; charset=utf-8', true, 404);
	echo 'invalid sitemap file';
}