<?php

namespace XF\ControllerPlugin;

use XF\Mvc\Entity\Entity;

class Node extends AbstractPlugin
{
	public function applyNodeContext(\XF\Entity\Node $node)
	{
		$this->controller->setContainerKey('node-' . $node->node_id);

		if ($node->effective_style_id)
		{
			$this->controller->setViewOption('style_id', $node->effective_style_id);
		}
		if ($node->effective_navigation_id)
		{
			$this->controller->setSectionContext($node->effective_navigation_id);
		}
	}
}