<?php

namespace XF;

class Phrase implements \JsonSerializable
{
	/**
	 * @var Language
	 */
	protected $language;

	protected $name;
	protected $params;

	public function __construct(Language $language, $name, array $params = [])
	{
		$this->language = $language;
		$this->name = $name;
		$this->params = $params;
	}

	public function render($context = 'html', array $options = [])
	{
		return $this->language->renderPhrase($this->name, $this->params, $context, $options);
	}

	public function __toString()
	{
		try
		{
			return $this->render();
		}
		catch (\Exception $e)
		{
			\XF::logException($e, false, 'Phrase rendering error: ');
			return htmlspecialchars($this->name);
		}
	}

	public function getName()
	{
		return $this->name;
	}

	public function getParams()
	{
		return $this->params;
	}

	public function setParams(array $params)
	{
		$this->params = $params;
	}

	public function jsonSerialize()
	{
		return $this->__toString();
	}
}