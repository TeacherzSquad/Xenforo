<?php

namespace XF\Cli\Command;

use Symfony\Component\Console\Output\OutputInterface;

trait JobRunnerTrait
{
	public function setupAndRunJob($uniqueId, $jobClass, array $params = [], OutputInterface $output = null)
	{
		\XF::app()->jobManager()->enqueueUnique($uniqueId, $jobClass, $params);

		$this->runJob($uniqueId, $output);
	}

	public function runJob($uniqueId, OutputInterface $output = null)
	{
		$jobManager = \XF::app()->jobManager();
		$em = \XF::em();

		while ($runner = $jobManager->runUnique($uniqueId, \XF::config('jobMaxRunTime')))
		{
			if ($output)
			{
				$output->writeln($runner->statusMessage);
			}

			// keep the memory limit down on long running jobs
			$em->clearEntityCache();
		}
	}
}