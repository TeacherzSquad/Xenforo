<?php

namespace XF\AddOn\DataType;

class CodeEventListener extends AbstractDataType
{
	public function getShortName()
	{
		return 'XF:CodeEventListener';
	}

	public function getContainerTag()
	{
		return 'code_event_listeners';
	}

	public function getChildTag()
	{
		return 'listener';
	}

	public function exportAddOnData($addOnId, \DOMElement $container)
	{
		$entries = $this->finder()
			->where('addon_id', $addOnId)
			->order(['event_id', 'callback_class', 'callback_method'])->fetch();

		foreach ($entries AS $entry)
		{
			$node = $container->ownerDocument->createElement($this->getChildTag());
			$this->exportMappedAttributes($node, $entry);
			$container->appendChild($node);
		}
		
		return $entries->count() ? true : false;
	}

	public function importAddOnData($addOnId, \SimpleXMLElement $container, $start = 0, $maxRunTime = 0)
	{
		$startTime = microtime(true);

		$entries = $this->getEntries($container, $start);
		if (!$entries)
		{
			return false;
		}

		$conditions = [];
		$existing = [];
		foreach ($entries AS $entry)
		{
			$conditions[] = [
				'addon_id' => $addOnId,
				'event_id' => (string)$entry['event_id'],
				'callback_class' => (string)$entry['callback_class'],
				'callback_method' => (string)$entry['callback_method']
			];
		}
		if ($conditions)
		{
			foreach ($this->finder()->whereOr($conditions)->fetch() AS $listener)
			{
				$existing[$listener->event_id][$listener->callback_class][$listener->callback_method] = $listener;
			}
		}
		else
		{
			$existing = [];
		}

		$i = 0;
		$last = 0;
		foreach ($entries AS $entry)
		{
			$i++;

			if ($i <= $start)
			{
				continue;
			}

			$event = (string)$entry['event_id'];
			$class = (string)$entry['callback_class'];
			$method = (string)$entry['callback_method'];
			$entity = isset($existing[$event][$class][$method]) ? $existing[$event][$class][$method] : $this->create();

			$entity->getBehavior('XF:DevOutputWritable')->setOption('write_dev_output', false);
			$this->importMappedAttributes($entry, $entity);
			$entity->addon_id = $addOnId;

			$entity->save(true, false);

			if ($this->resume($maxRunTime, $startTime))
			{
				$last = $i;
				break;
			}
		}
		return ($last ?: false);
	}

	public function deleteOrphanedAddOnData($addOnId, \SimpleXMLElement $container)
	{
		$existing = [];
		foreach ($this->findAllForType($addOnId)->fetch() AS $listener)
		{
			$existing[$listener->event_id][$listener->callback_class][$listener->callback_method] = $listener;
		}
		if (!$existing)
		{
			return;
		}

		$entries = $this->getEntries($container) ?: [];

		foreach ($entries AS $entry)
		{
			$event = (string)$entry['event_id'];
			$class = (string)$entry['callback_class'];
			$method = (string)$entry['callback_method'];

			if (isset($existing[$event][$class][$method]))
			{
				unset($existing[$event][$class][$method]);
			}
		}

		array_walk_recursive($existing, function($entity)
		{
			if ($entity instanceof \XF\Entity\CodeEventListener)
			{
				$entity->getBehavior('XF:DevOutputWritable')->setOption('write_dev_output', false);
				$entity->delete();
			}
		});
	}

	public function rebuildActiveChange(\XF\Entity\AddOn $addOn, array &$jobList)
	{
		\XF::runOnce('rebuild_active_' . $this->getContainerTag(), function()
		{
			/** @var \XF\Repository\CodeEventListener $repo */
			$repo = $this->em->getRepository('XF:CodeEventListener');
			$repo->rebuildListenerCache();
		});
	}

	protected function getMappedAttributes()
	{
		return [
			'event_id',
			'execute_order',
			'callback_class',
			'callback_method',
			'active',
			'hint',
			'description'
		];
	}
}