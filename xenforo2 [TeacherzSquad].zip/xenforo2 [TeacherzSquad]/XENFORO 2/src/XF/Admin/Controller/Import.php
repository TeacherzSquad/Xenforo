<?php

namespace XF\Admin\Controller;

use XF\Mvc\ParameterBag;
use XF\Mvc\FormAction;

class Import extends AbstractController
{
	protected function preDispatchController($action, ParameterBag $params)
	{
		$this->assertAdminPermission('import');
	}

	public function actionIndex()
	{
		// TODO: implement this at some point. Note that the admin nav link is currently only displayed in debug mode.
		return $this->message('This functionality is not yet available.');
	}
}