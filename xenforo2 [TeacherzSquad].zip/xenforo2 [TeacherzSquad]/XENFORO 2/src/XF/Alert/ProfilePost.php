<?php

namespace XF\Alert;

use XF\Mvc\Entity\Entity;

class ProfilePost extends AbstractHandler
{
	public function getEntityWith()
	{
		return ['ProfileUser', 'ProfileUser.Privacy'];
	}

	public function getOptOutActions()
	{
		return [
			'insert',
			'mention',
			'like'
		];
	}

	public function getOptOutDisplayOrder()
	{
		return 20000;
	}
}