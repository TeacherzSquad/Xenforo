<?php

namespace XF\Alert;

class ConversationMessage extends AbstractHandler
{
	public function getEntityWith()
	{
		return ['Conversation'];
	}
}