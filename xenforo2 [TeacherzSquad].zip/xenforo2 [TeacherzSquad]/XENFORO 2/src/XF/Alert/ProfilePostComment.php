<?php

namespace XF\Alert;

class ProfilePostComment extends AbstractHandler
{
	public function getOptOutActions()
	{
		return [
			'your_profile',
			'your_post',
			'other_commenter',
			'like'
		];
	}

	public function getOptOutDisplayOrder()
	{
		return 20005;
	}
}